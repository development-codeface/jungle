     </div>
  
  <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url();?>assets/js/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url();?>assets/js/jquery.js"></script>

   <script>
   
      	var base_url = '<?php echo base_url();?>';
	 	var li = $("#alert-dropdown li").length;
	 	
	 	if(li == 0) { $("#alert-dropdown").hide(); }
	 	else { $("#alert_count").html(li); }
      </script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <!-- <script src="<?php echo base_url();?>assets/js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/morris-data.js"></script> -->
    
  <!-- <script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script> -->
    <script src="<?php echo base_url();?>assets/js/rooms.js"></script>
     <script src="<?php echo base_url();?>assets/js/confirm.js"></script>
    

         <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.validate.min.js"></script>
      <script src="<?php echo base_url();?>assets/js/script.js"></script>
         <script src="<?php echo base_url();?>assets/js/bootstrap-datepicker.js" type="text/javascript"></script>
   
    <script src="<?php echo base_url();?>assets/js/custom.js"></script>
     <script src="<?php echo base_url();?>assets/js/booking.js"></script>
      <script src="<?php echo base_url();?>assets/js/ayurveda.js"></script>
       <script src="<?php echo base_url();?>assets/js/custom_val.js"></script>
	<script src="<?php echo base_url();?>assets/js/ckeditor/ckeditor.js"></script>
	<script src="<?php echo base_url();?>assets/js/offline.js"></script>
	<script src="<?php echo base_url();?>assets/js/user.js"></script>

      <script>
      	var baseurl = '<?php echo base_url();?>';
      </script>
</body>

</html>

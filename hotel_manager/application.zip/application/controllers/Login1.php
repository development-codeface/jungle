<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index() {

		$this -> load -> view('layout/index');
	}

	public function login_form() {

		if (isset($this -> session -> userdata['hotel_adminusername'])) {
			redirect('dashboard');
		} else {
			$this -> form_validation -> set_rules('username', 'Username', 'required');
			$this -> form_validation -> set_rules('password', 'Password', 'required|md5');

			if ($this -> form_validation -> run() == FALSE) {
				$data['validation'] = validation_errors();
				$this -> load -> view('index', $data);
			} else {

				$data['username'] = $this -> input -> post('username');
				$data['password'] = $this -> input -> post('password');

				$this -> db -> select('*');
				$this -> db -> where('password', $data['password']);
				$this -> db -> where('username', $data['username']);
				$this -> db -> where('status', '1');
				$query_res = $this -> db -> get('tbl_hotel_manager');
				$result = $query_res -> result();

				if (!empty($result)) {
					$admindata = array('hotel_adminusername' => $data['username'], 'category' => '');

					$this -> session -> set_userdata($admindata);
					$data['hotel_admin_session'] = $this -> session -> all_userdata();
					redirect('dashboard');
				} else {
					redirect('login');
				}

			}

		}

		$this -> load -> view('layout/index');
	}

	public function admin_login($id, $category) {

		$this -> db -> select('*');
		$this -> db -> where('hotel_id', $id);
		$this -> db -> where('status', '1');
		$query_res = $this -> db -> get('tbl_hotel_manager');
		$result = $query_res -> result();
		if (!empty($result)) {
			$admindata = array('hotel_adminusername' => $result[0] -> username, 'category' => $category);

			$this -> session -> set_userdata($admindata);
			$data['hotel_admin_session'] = $this -> session -> all_userdata();

			redirect('dashboard');
		} else {
			redirect('login');
		}

	}

	public function logout() {

		$this -> session -> unset_userdata('hotel_adminusername');
		$this -> session -> unset_userdata('category');
		redirect('login', 'refresh');

	}

	function forgot_pass() {

		if (isset($_POST['submit'])) {
			$data['email'] = $this -> input -> post('email');

			$query = $this -> db -> where('mail', $data['email']) -> get('tbl_hotel') -> num_rows();

			if ($query > 0) {
				$hotel = $this -> db -> where('mail', $data['email']) -> get('tbl_hotel') -> row();
				
				$rand = rand();
				$data1['password'] = md5($rand);

				$this -> db -> where('hotel_id', $hotel -> id) -> update('tbl_hotel_manager', $data1);
				
				$to = $data['email'];
				$subject = 'Password Reset';
				$message = 'Hi,<br/><br/>
			Your password changed successfully.<br/><br/>
			New Password :' . $rand . '<br/><br/>
			Thank you for using our service.';
				$headers = 'MIME-Version: 1.0' . "\r\n";
				$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				$headers .= 'From: BookingWings<info@crantia.com>' . "\r\n";
				mail($to, $subject, $message, $headers);

				$this -> session -> set_flashdata('success', 'Password reset successful, mail sent to '.$to);
				redirect('login/');
			} else {
				$this -> session -> set_flashdata('error', 'Error : E-mail not found');
				redirect('login/');
			}
		}

	}

}

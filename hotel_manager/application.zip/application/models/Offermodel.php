<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Offermodel extends CI_Model {

  
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function get_offers($id, $limit, $start)
	{
		$this -> db -> select('b.*');
		$this -> db -> from('tbl_hotel a');
		$this -> db -> join('tbl_offers b', 'a.id = b.hotel_id');
		$this -> db -> where('a.id', $id);
		$this->db->order_by('b.id','desc');
		$this -> db -> limit($limit, $start);
		$query = $this -> db -> get();
		return $query -> result();
	}
	
	function get_offers_count($id)
	{
		$this -> db -> select('b.*');
		$this -> db -> from('tbl_hotel a');
		$this -> db -> join('tbl_offers b', 'a.id = b.hotel_id');
		$this -> db -> where('a.id', $id);
		$query = $this -> db -> get();
		$result = $query -> result();
		return count($result);
	}
	
	function offer($id)
	{
		$query = $this -> db -> where('id', $id) -> get('tbl_offers');
		return $query -> row();
	}
}

?>
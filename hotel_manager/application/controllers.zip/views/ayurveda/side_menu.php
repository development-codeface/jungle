
<div class="collapse navbar-collapse navbar-ex1-collapse side_menu_cus">
                <ul class="nav navbar-nav side-nav">
               
               
               <div style="background: rgba(255,255,255,0.7); min-height: 75px;  ">
                		
                		<img src="<?php echo base_url();?>assets/img/hotel_logo1.png.png" style="width:100%;" />
                		
                	</div>
                	
                	
                	
                   <li >
                        <a href="javascript:;" data-toggle="" data-target=""><img src="<?php echo base_url();?>assets/img/yoga_img.png" />Yoga<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="" class="">
                           <li>
                                <a href="<?php echo base_url('ayurveda/list_yoga');?>"><i class="fa fa-fw fa-table"></i> Manage Yoga</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('ayurveda/room_setting/yoga');?>"><i class="fa fa-fw fa-table"></i> Rate & Availability</a>
                            </li>
                        </ul>
                    </li>
                    
                   <li >
                        <a href="javascript:;" data-toggle="" ><img src="<?php echo base_url();?>assets/img/ayurveda_img.png " /> Ayurveda<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul  class="">
                          
                               <li>
                                <a href="<?php echo base_url('ayurveda/list_ayurveda');?>"><i class="fa fa-fw fa-table"></i> Manage Ayurveda</a>
                              </li>
                              <li>
                                <a href="<?php echo base_url('ayurveda/room_setting/ayurveda');?>"><i class="fa fa-fw fa-table"></i> Rate & Availability</a>
                            </li>
                        </ul>
                    </li>
                    
                
                    
                </ul>
            </div>

  </nav>
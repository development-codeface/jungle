
<div id="page-wrapper">

            <div class="container-fluid profile-block-cus rooms_list_block_cus">

            
                <!-- Page Heading << -->
                


				
				
				<div class="row">
                    <div class="col-lg-12 col-sm-offset-1">
                      
                           
                            <div class="panel-body panel_promo">
								<div class="panel panel_white col-lg-5 pad_out left_promo">
									<div class="panel-heading">
										<div class="row">
											<div class="col-xs-3">
										
											</div>
											<div class="col-xs-9 text-right">
												
												<div class="sms-send">Sorry No Permission</div>
											</div>
										</div>
									</div>
                           
                            
							</div>
					
						</div>
						
                    <div id="page">
                   <?php if(!empty($userid)): echo $pagination; endif;?></div>
                    </div>
                    
                </div>
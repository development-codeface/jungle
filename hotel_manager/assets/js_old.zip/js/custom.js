$(function() {
    //$( "#tabs" ).tabs();
	 //getsubcat();
	 getcountry();
    $(".hotel_image_add").click(function(e)
    {

    	var html ='<div class="form-group col-lg-12"><input class="col-lg-11  " type="file" name="hotel_image[]"><div class="pull-left" style="margin-top: 5px;"><button type="button" class="btn btn-xs btn-danger pull-left hotel_image_remove" onClick="remove_hotel_image(this)"  >Remove</button></div></div>';
        $(".hotel_image_row").append(html);
    });
    $(".room_combination_add").click(function(e)
    {
    	var html = $('.room_combination_row .row').first().html();
		//alert(html);
		var html1 = html.replace('<button type="button" class="btn btn-success room_combination_add">Add</button>','<button type="button" class="btn btn-success " onClick="room_combination_remove(this)">Remove</button>');
		html1 = '<div class="form-group row">'+html1+'</div>';
        $(".room_combination_row").append(html1);
    });
	$(".catagory").change(function() {
	  //getsubcat();
	});
	$("#country").change(function() {
	  getcountry();
	});
	
	$(".states").change(function() {
	  getdistrict();
	});
	
	
function ChangeUrl(title, url) {
	if ( typeof (history.pushState) != "undefined") {
		var obj = {
			Title : title,
			Url : url
		};
		history.pushState(obj, obj.Title, obj.Url);
	} else {
		alert("Browser does not support HTML5.");
	}
}
	
	
});
  function getcountry()
  {
	$.ajax( {
		  type: "POST",
		  url: base_url+"profile/select_state/"+$('#state_hidden').val(),
		  data: {cat: $('.country').val()  }
		})
	  .done(function(data) {
		$(".state").html(data);
	  })
	  .fail(function() {
		//alert( "error" );
	  });  
  }
  
  function getdistrict()
  {
  	
  	
	$.ajax( {
		  type: "POST",
		  url: base_url+"profile/select_district/"+$('.states').val(),
		  data: {cat: $('.states').val()  }
		})
	  .done(function(data) {
	  	
		$(".district").html(data);
	  })
	  .fail(function() {
		//alert( "error" );
	  });  
  }
  
  
function remove_hotel_image(ele)
{
	$(ele).parent().parent().remove();
}
function room_combination_remove(ele)
{
	$(ele).parent().parent().remove();
}



//date picker
var date = new Date();

$('#sandbox-container input').datepicker({
    format: 'dd-mm-yyyy',
	startDate : date,
	autoclose: true
});
	
$('#sandbox-container2 input').datepicker({
	format: "yyyy-mm", 
    minViewMode: 1,
    autoclose: true
});

$('#sandbox-container3 input').datepicker({
	format: 'dd-mm-yyyy',
    autoclose: true
});

function room_settings(id)
{
	$.ajax({
		type: "POST",
		url: base_url+"booking/checkout/"+id,
		success: function(data) {
		//$("#monthly").html(data);
	  }
	});
}	


function room_settings(id)
{
	var date = new Date();
	$.ajax({
		type: "POST",
		url: base_url+"booking/checkout/"+id,
		success: function(data) {
			$("#myModal").html(data);
			$('#sandbox-container input').datepicker({ format: 'yyyy-mm-dd', startDate: date });
	  }
	});
}	



function get_month()
{
	var m = $('#month').val()+'-';
	$.ajax({
		type: "POST",
		url: base_url+"report/day_names/"+m,
		success: function(data) {
		$("#monthly").html(data);
	  }
	});
}


function get_month1()
{
	var m = $('#month').val()+'-';
	$.ajax({
		type: "POST",
		url: base_url+"report/day_names1/"+m,
		success: function(data) {
		$("#monthly").html(data);
	  }
	});
}


function get_checkin()
{
	var m = $('#month').val()+'-';
	$.ajax({
		type: "POST",
		url: base_url+"report/checkin/"+m,
		success: function(data) {
		$("#monthly").html(data);
	  }
	});
}

function get_checkout()
{
	var m = $('#month').val()+'-';
	$.ajax({
		type: "POST",
		url: base_url+"report/checkout/"+m,
		success: function(data) {
		$("#monthly").html(data);
	  }
	});
}

function get_dates()
{
	var frm = $('#from').val();
	var to = $('#to').val();
	var agn = $('#agency').val();
	if(frm&&to&&agn) {
	$.ajax({
		type: "POST",
		url: base_url+"report/agency/"+frm+"/"+to+"/"+agn,
		success: function(data) {
		$('#page-wrap').html(data);
			ChangeUrl('Page1', baseurl + "report/agency/"+frm+"/"+to+"/"+agn);
		}
	});
	}
}


function get_dates_direct()
{
	var frm = $('#from').val();
	var to = $('#to').val();
	if(frm&&to) {
	$.ajax({
		type: "POST",
		url: base_url+"report/direct/"+frm+"/"+to,
		success: function(data) {
		$('#page-wrap').html(data);
			ChangeUrl('Page1', baseurl + "report/direct/"+frm+"/"+to);
		}
	});
	}
}


function get_dates_online()
{
	var frm = $('#from').val();
	var to = $('#to').val();
	if(frm&&to) {
	$.ajax({
		type: "POST",
		url: base_url+"report/online/"+frm+"/"+to,
		success: function(data) {
		$('#page-wrap').html(data);
			ChangeUrl('Page1', baseurl + "report/online/"+frm+"/"+to);
		}
	});
	}
}


function coupon_search()
{
	var key = $('#search').val();
	if(key)
	{
	$.ajax({
		type: "POST",
		url: base_url+"coupon/search/"+key,
		success: function(data) {
		$("#result").html(data);
	  }
	});
	}
}




//validation for add/edit staff form

(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            $("#site_users").validate({
            	
            rules: {
                name: {
                	required: true
				},
				
				username: {
					required: true
				},
				
                new_password: {
					required: true
                },
				
                confirm_password: {
					required: true
                },
             },
             messages: {
             	name: "Please enter a name",
             	username: "Please enter username",
             	new_password: "Please enter a password",
             	confirm_password: "Please confirm the password",
             },
                submitHandler: function(form) {
                  form.submit();
                }
               
               
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);


//validation for change password form

(function($,W,D)
{
    var JQUERY4U = {};

    JQUERY4U.UTIL =
    {
        setupFormValidation: function()
        {
            $("#change_pass").validate({
            	
            rules: {
				old_password: {
					required: true
				},
				
                new_password: {
					required: true
                },
				
                confirm_password: {
					required: true
                },
              },
             messages: {
             	old_password: "Please enter current password",
             	new_password: "Please enter new password",
             	confirm_password: "Please confirm new password"
             },
              
                submitHandler: function(form) {
                  form.submit();
                }
               
               
            });
        }
    }

    //when the dom has loaded setup form validation rules
    $(D).ready(function($) {
        JQUERY4U.UTIL.setupFormValidation();
    });

})(jQuery, window, document);
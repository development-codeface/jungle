function get_booking_list() {
	var cat = $('#category').val();
	var cin = $('#check_in').val();
	var cout = $('#check_out').val();
	var stat = $('input[name=status]:checked').val();
	if(!cat) { cat = 'both'; }
	if(!stat) { stat = '0'; }
	$.ajax({
		url : baseurl + "booking/get_booking/"+cat+"/"+cin+"/"+cout+"/"+stat,
		type : "POST",
		success : function(result) {
			//alert(result);
			$('#page-wrapper').html(result);
			ChangeUrl('Page1', baseurl + "booking/get_booking/"+cat+"/"+cin+"/"+cout+"/"+stat);
		}
	});
}



function ChangeUrl(title, url) {
	if ( typeof (history.pushState) != "undefined") {
		var obj = {
			Title : title,
			Url : url
		};
		history.pushState(obj, obj.Title, obj.Url);
	} else {
		alert("Browser does not support HTML5.");
	}
}


function checkin_date() {
	var date = $('#check_in').val();
	$.ajax({
		url : baseurl + "booking/checkin_list_date/" + date,
		type : "POST",
		success : function(result) {
			$('#page-wrapper').html(result);
			$('#check_in').val(date);
			ChangeUrl('Page1', baseurl + 'booking/checkin_list_date/' + date);
		}
	});
}


function room_checkin(book_room_id,booking_id)
{
		var name=$('#name'+book_room_id).val();
		var email=$('#email_id'+book_room_id).val();
		var phone=$('#phone'+book_room_id).val();
		
		if(name && email && phone)
		{
			$.ajax({
			url : baseurl + "booking/checkin/",
			type : "POST",
			data :{ name : name, email : email, phone : phone, book_room_id:book_room_id, booking_id : booking_id},
			success : function(result) {
				
				if(result==1)
				{
					alert('user checkin');
					$('#checkin'+book_room_id).prop('disabled',true);
				}
				else
				{
					alert('some Problem affected');
				}			
			}
			});
	
	}
	else
	{
		alert('Please fill this fields');
	}
	
	

}

function room_checkout(book_room_id,booking_id)
{
		
			$.ajax({
			url : baseurl + "booking/checkout/",
			type : "POST",
			data :{ book_room_id:book_room_id, booking_id : booking_id},
			success : function(result) {
				
				if(result==1)
				{
					alert('user checkout');
					$('#checkin'+book_room_id).prop('disabled',true);
					
				}
				else
				{
					alert('some Problem affected');
				}			
			}
			});
	

}



function advance_amount()
{
	var amount=$('#advance').val();
	var booking_number=$('#booking_number').val();
	var voucher = $('#voucher').val();
	
	
	$.ajax({
			url : baseurl + "booking/advance/",
			type : "POST",
			data :{ amount:amount, booking_number : booking_number, voucher : voucher},
			success : function(result) {
				
				
				if(result>=1)
				{
					
					alert('Advance amount payed');
					location.reload();
					
				}
				else
				{
					alert('some Problem affected');
				}			
			}
			});
			
	
}


$('#checkin_user_details').click(function()
{
	var name = $('.username').val();
	var email = $('.useremail').val();
	var phone = $('.userphone').val();
	
	$('.username').val(name);
	$('.useremail').val(email);
	$('.userphone').val(phone);
	
	
});

function interchange_room()
{
	
	var check_in = $('#check_in').val();
	var check_out = $('#check_out').val();
	var room = $('#room_type').val();
	
	$.ajax({
		
		url: baseurl + 'booking/avail_interchange_rooms',
		type:'POST',
		data : {check_in : check_in, check_out:check_out, room: room},
		success: function(res)
		{
			
			$('#rooms').html(res);
		}
		
	});
}



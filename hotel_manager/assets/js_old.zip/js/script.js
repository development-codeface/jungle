// function check_username()
// {	
	// var email = $('#email').val();
// 
	// var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	// if (filter.test(email)) {
// 
// 
		// $.ajax({
			// type : "post",
			// url : baseurl + "travels/check_username/" + email,
			// success : function(res)
			// {
				// if (res != '')
				// {
					// $('#email_exist').html(res);
// 
				// } else
				// {
					// $('#email_exist').html('');
				// }
// 
			// }
		// });
// 
	// } else {
		// $('#email_exist').html('');
		// return false;
	// }
// 	
// }


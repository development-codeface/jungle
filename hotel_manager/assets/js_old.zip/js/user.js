$('.user_status').change(function()
	{
		var status = $('input:radio[name=status]:checked').val();
		
			$.ajax({
				type: "post",
				url: baseurl+"users/user_status/"+status,
				data: {status : status},
				success:function(res)
				{
					
					var result = res.split("|");
					$('#users').html(result[0]);
					$('#page').html(result[1]);
					ChangeUrl('Page1', baseurl+'users/users_status/'+status); 
					
				}
				
			});
		
		
});

function ChangeUrl(title, url) {
		    if (typeof (history.pushState) != "undefined") {
		        var obj = { Title: title, Url: url };
		        history.pushState(obj, obj.Title, obj.Url);
		    } else {
		        alert("Browser does not support HTML5.");
		    }
		
		}

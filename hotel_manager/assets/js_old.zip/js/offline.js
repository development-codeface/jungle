
//date picker
var date = new Date();
$('#agency_voucher').css("display", "none");
$('#agency_commision').css("display", "none");

$('#sandbox-container-chart input').datepicker({ format: 'dd-mm-yyyy'});




function getRoomsBed(id)
{
	
	var days = $('#total_days').val();
	if(days==0)
	 { days =1;}
	var tot = $('#total').val();
	var total_room_amount=$('#total_hid').val();
	var extra_amount=$('#extra_amount'+id).val();
	 var cat = $('#type').val();	
	  var tax=$('#hotel_tax').val();
	 var commision=$('#commision').val();
	 var food_plan =$('#total_food').val();
	 
	
	
	if(tot)
	{
		
	var bed = $('#extra_bed'+id).val();
	var rate = $('#extra_bed_rate'+id).val();
	var bed_count = $('#bed_count_'+id).text();
	var room_count = $('.room_count_'+id).text();
	
	
	if(bed>bed_count)
	{
		var bed = bed_count;
		$('#extra_bed'+id).val(bed);
		
		alert('You have to select maximum '+ bed +' extra bed(s)');
	}
	
	var total_bed_rate= days * bed * rate;
	var old_amount= tot - extra_amount;
	var rate_tot =Number(old_amount) + Number(days * bed * rate);
	
	
		if(cat==0)
		{
			if(food_plan!='')
			{
				var final_room_amount = Number(rate_tot) + Number(food_plan);
			}
			else
			{
				var final_room_amount = rate_tot;
			}
			
			var tax_amount = ((final_room_amount)*tax)/100;
			var total_tax_price=tax_amount+(final_room_amount);
			var discount = $('#discount').val();
			if(discount!='')
			{
				var total_tax =total_tax_price - discount;
			}
			else
			{
				var total_tax =total_tax_price;
			}
		
			
		}
		else
		{
			var lastChar = commision.substr(commision.length - 1);
			if(lastChar=='%')
			{
				var result = commision.slice(0, -1);
				var commision_amount = ((rate_tot)*result)/100;
				
			}
			else
			{
				var commision_amount = commision;
			}
			var total_commision=(rate_tot) - commision_amount;
			var tax_amount = ((total_commision)*tax)/100;
			var total_tax=tax_amount+(total_commision);
			
		}
		
		
	$('#total').val(rate_tot);
	$('#extra_amount'+id).val(total_bed_rate);
	$('#tax').val(tax_amount);
	$('#agency').val(commision_amount);
	$('#net_amount').val(Math.round(total_tax));
	

	
	
	}
}


function getChilds(id)
{
	
	var days = $('#total_days').val();
	if(days==0)
	 { days =1;}
	var tot = $('#total').val();
	var total_room_amount=$('#total_hid').val();
	var extra_child_amount=$('#extra_child_amount'+id).val();
	var cat = $('#type').val();	
	 var tax=$('#hotel_tax').val();
	 var commision=$('#commision').val();
	 var food_plan =$('#total_food').val();
	
	if(tot)
	{
		
	var childs = $('#childs'+id).val();
	var rate = $('#extra_child_rate'+id).val();
	var child_count = $('#child_count_'+id).text();
	var room_count = $('.room_count_'+id).text();
	
	
	if(childs>child_count)
	{
		var childs = child_count;
		$('#childs'+id).val(childs);
		
		alert('You have to allowed maximum '+ childs +' children(s)');
	}
	
	var total_child_rate= days * childs * rate;
	
	
	var old_amount= tot - extra_child_amount;
	var rate_tot =Number(old_amount) + Number(days * childs * rate);
	
	
	if(cat==0)
		{
			
			if(food_plan!='')
			{
				var final_room_amount = Number(rate_tot) + Number(food_plan);
			}
			else
			{
				var final_room_amount = rate_tot;
			}
			var tax_amount = ((final_room_amount)*tax)/100;
			var total_tax_price=tax_amount+(final_room_amount);
			var discount = $('#discount').val();
			if(discount!='')
			{
				var total_tax =total_tax_price - discount;
			}
			else
			{
				var total_tax =total_tax_price;
			}
		
			
		}
		else
		{
			var lastChar = commision.substr(commision.length - 1);
			if(lastChar=='%')
			{
				var result = commision.slice(0, -1);
				var commision_amount = ((rate_tot)*result)/100;
				
			}
			else
			{
				var commision_amount = commision;
			}
			var total_commision=(rate_tot) - commision_amount;
			var tax_amount = ((total_commision)*tax)/100;
			var total_tax=tax_amount+(total_commision);
			
		}
		
		
	
	$('#total').val(rate_tot);
	$('#extra_child_amount'+id).val(total_child_rate);
	$('#tax').val(tax_amount);
	$('#agency').val(commision_amount);
	$('#net_amount').val(Math.round(total_tax));
	}
}

function getRooms(id,room_id,roomno_id)
{
	 var days = $('#total_days').val();
	 if(days==0)
	 { days =1;}
	 
	 var hid = $('#total_hid').val();
	 var total =$('#total').val();
	 var no_of_bed = $('#no_of_bed_'+id).val();
	 var no_of_child = $('#no_of_child_'+id).val();
	 var extra_amount=$('#extra_amount'+id).val();
	 
	 var bed_count = $('#bed_count_'+id).text();
	 var child_count = $('#child_count_'+id).text();
	 var room_count = $('.room_count_'+id).text();
	 var tax=$('#hotel_tax').val();
	 var commision=$('#commision').val();
	 var food_plan =$('#total_food').val();
	 var cat = $('#type').val();	
	
	var checkedValues=[];
	var sp,tot = 0,rate = 0,bed = 0,rate_tot = 0;
/* 	
	$('input:checkbox:checked').each(function() {
		checkedValues.push($(this).val());
	}).get(); */
	
	
	$('input:checkbox.numberrooms:checked').each(function () {
     checkedValues.push($(this).val());
  });
  
	
	
	for(var i=0;i<checkedValues.length;i++)
	{
		sp = checkedValues[i].split("|");
		tot+=Number(sp[3]*days);
		
	}
	
	var selected_room_count =$('input.room_check'+id+':checked').length;
	var max_bed = selected_room_count * no_of_bed;
	var max_child=selected_room_count * no_of_child;
	
	$('#bed_count_'+id).text(max_bed);
	$('#child_count_'+id).text(max_child);
	$('.room_count_'+id).text(selected_room_count);
	
	
	if(hid!='')
	{
		
		if($('.room_check'+id).is(":checked"))
		{
			
			if($('.check_room_'+id+'_'+roomno_id).is(":checked"))
			{
				
				$('.check_room_number_'+room_id+'_'+roomno_id).prop('disabled',true);
				$('.check_room_'+id+'_'+roomno_id).prop('disabled',false);
				
				var new_amount = total - hid;
		    	var final_amount = tot + new_amount;
			
			}
			else
			{
				$('.check_room_number_'+room_id+'_'+roomno_id).prop('disabled',false);
				$('.check_room_'+id+'_'+roomno_id).prop('disabled',false);
				
				var bed = $('#extra_bed'+id).val();
				var rate = $('#extra_bed_rate'+id).val();
		    	
				
				if(bed > max_bed)
				{
					$('#extra_bed'+id).val(max_bed);
					var bed_rate = days * max_bed * rate;
					var total_bed_rate= days * max_bed * rate;
					
					var new_amount = (total - hid) -(extra_amount -total_bed_rate);
					var final_amount = tot + new_amount;
					
					$('#extra_amount'+id).val(total_bed_rate);
					
			    	alert('You have to select maximum '+ bed +' extra bed(s)');
				}
				else
				{
					var new_amount = total - hid;
					var final_amount = tot + new_amount;
				}
				
				 
			}
			
			$('#extra_bed'+id).prop('disabled',false);
			$('#childs'+id).prop('disabled',false);
			$('#discount').prop('disabled',false);
			
			
			
			
		}
		else
		{
			//last
			
			$('#bed_count_'+id).text(no_of_bed);
			$('#child_count_'+id).text(no_of_child);
			$('.room_count_'+id).text('1');
	
			$('.check_room_number_'+room_id+'_'+roomno_id).prop('disabled',false);
			$('.check_room_'+id+'_'+roomno_id).prop('disabled',false);
				
			var bed = $('#extra_bed'+id).val();
			var rate = $('#extra_bed_rate'+id).val();
			var bed_rate = days * bed * rate;
			
			var new_amount = total - hid - bed_rate;
			
	    	var final_amount = tot + new_amount;
	    	
	    	$('#extra_bed'+id).prop('disabled',true);
			$('#childs'+id).prop('disabled',true);
			$('#extra_bed'+id).val('');
			$('#childs'+id).val('');
			$('#extra_amount'+id).val('');
			
		}
		if(cat==0)
		{
			if(food_plan!='')
			{
				var final_room_amount = Number(final_amount) + Number(food_plan);
			}
			else
			{
				var final_room_amount = final_amount;
			}
			var tax_amount = ((final_room_amount)*tax)/100;
			var total_tax_price=tax_amount+(final_room_amount);
			var discount = $('#discount').val();
			if(discount!='')
			{
				var total_tax =total_tax_price - discount;
			}
			else
			{
				var total_tax =total_tax_price;
			}
		
			
		}
		else
		{
			var lastChar = commision.substr(commision.length - 1);
			if(lastChar=='%')
			{
				var result = commision.slice(0, -1);
				var commision_amount = ((final_amount)*result)/100;
				
			}
			else
			{
				var commision_amount = commision;
			}
			var total_commision=(final_amount) - commision_amount;
			var tax_amount = ((total_commision)*tax)/100;
			var total_tax=tax_amount+(total_commision);
			
		}
		
		$('#total').val((final_amount));
		$('#total_hid').val((tot));
		$('#tax').val(tax_amount);
		$('#agency').val(commision_amount);
		$('#net_amount').val(Math.round(total_tax));
		
	
	}
	else
	{
		
		
		if($('.room_check'+id).is(":checked"))
		{
			if($('.check_room_'+id+'_'+roomno_id).is(":checked"))
			{
				
				$('.check_room_number_'+room_id+'_'+roomno_id).prop('disabled',true);
				$('.check_room_'+id+'_'+roomno_id).prop('disabled',false);
			}
			else
			{
				
				$('.check_room_number_'+room_id+'_'+roomno_id).prop('disabled',false);
				$('.check_room_'+id+'_'+roomno_id).prop('disabled',false);
			}
			
			$('#extra_bed'+id).prop('disabled',false);
			$('#childs'+id).prop('disabled',false);
			$('#discount').prop('disabled',false);
			
			var new_amount = total - hid;
	    	var final_amount = tot + new_amount;
		}
		else
		{
			var bed = $('#extra_bed'+id).val();
			var rate = $('#extra_bed_rate'+id).val();
			var bed_rate = days * bed * rate;
			
			
			
			var new_amount = total - hid - bed_rate;
	    	var final_amount = tot + new_amount;
			
			$('#extra_bed'+id).prop('disabled',true);
			$('#childs'+id).prop('disabled',true);
			$('#extra_bed'+id).val('');
			$('#childs'+id).val('');
			$('#extra_amount'+id).val('');
						
		}
		
		if(cat==0)
		{
			if(food_plan!='')
			{
				var final_room_amount = Number(final_amount) + Number(food_plan);
			}
			else
			{
				var final_room_amount = final_amount;
			}
			var tax_amount = ((final_room_amount)*tax)/100;
			var total_tax_price=tax_amount+(final_room_amount);
			
			var discount = $('#discount').val();
			if(discount)
			{
				var total_tax=total_tax_price - discount;
			}
			else
			{
				var total_tax=total_tax_price;
			}
		}
		else
		{
			var lastChar = commision.substr(commision.length - 1);
			if(lastChar=='%')
			{
				var result = commision.slice(0, -1);
				var commision_amount = ((final_amount)*result)/100;
			}
			else
			{
				var commision_amount = commision;
			}
			var total_commision=(final_amount) - commision_amount;
			var tax_amount = ((total_commision)*tax)/100;
			var total_tax=tax_amount+(total_commision);
			
		}
		
		$('#total').val((tot));
		$('#total_hid').val((tot));
		$('#tax').val(tax_amount);
		$('#agency').val(commision_amount);
		$('#net_amount').val(Math.round(total_tax));
	
		
	}
	
	if(checkedValues.length=='0')
	{
		$('#discount').val('');
		$('#total').val('');
		$('#tax').val('');
		
		$('#discount').prop('disabled',true);
		$('#hid_discount').val('');
	}
}



function discount_amount()
{
	 var hid = $('#hid_net_amount').val();
	
	var old_disc=$('#hid_discount').val();
	var disc = $('#discount').val();
	var tot = $('#total').val();
	var net_amount = $('#net_amount').val();
	
	if(Number(disc) > Number(net_amount))
	{
		if(old_disc)
		{
			var new_val=Number(net_amount)+Number(old_disc);
			$('#net_amount').val(new_val);
		}
		else
		{
			$('#net_amount').val(net_amount);
		}
		
		var old_disc=$('#hid_discount').val('');
		var disc = $('#discount').val('');
	}
	else
	{
		
		if(net_amount!='')
		{
			if(disc=='')
			{
				if(old_disc)
				{
					var new_val=Number(net_amount)+Number(old_disc);
					$('#net_amount').val(new_val);
					$('#hid_discount').val(disc);
				}
				
			}
			else
			{
				if(old_disc)
				{
					var new_val=(Number(net_amount)+Number(old_disc)) - Number(disc);
					$('#net_amount').val(new_val);
					$('#hid_discount').val(disc);
				}
				else
				{
					var new_val=(Number(net_amount) - Number(disc));
					$('#net_amount').val(new_val);
					$('#hid_discount').val(disc);
				}
				
			}
		
		}
	
	}
	
	

}


function room_available()
{
	
	var check_in = $('#check_in').val();
	var check_out = $('#check_out').val();
	var status =  $('.status:checked').val();
	
	//if(((check_in) && (check_out)) && (check_out >= check_in) && (status))
	if(((check_in) && (check_out)) && (status))
	{
	  	 $.ajax({
		  url: baseurl + "offline/get_rooms/"+check_in+"/"+check_out+"/"+status,
		  type:"POST",
	  	  success:function(result){
	  	  	
	  	  	//alert(result);
		 $("#room_status").html(result);
	
	  	}});
		
	}
	
}


function offline_room_check()
{
	var check_in = $('#check_in').val();
	var check_out = $('#check_out').val();
	var cat = $('#type').val();	
	var category = $('input[name="category"]:checked').val();
	if(category=='package')
	{
	
		package_room_check();
	}
	else
	{
		//	if(((check_in) && (check_out)) && check_out >= check_in)
		if(((check_in) && (check_out)))
		{
			 $.ajax({
			  url: baseurl + "offline/room_available/"+check_in+"/"+check_out+"/"+cat,
			  type:"POST",
			  success:function(result){
				
				//alert(result);
			 $("#room_available").html(result);
			
			if(cat!=0)
			{
				$('#food_paln').css("display", "none");
			}
		
			}});
			
		} 
		else { $("#room_available").html(''); }
	}
	
	$('.extra_amount').val('');
	$('#total').val('');
	$('#hid_discount').val('');
	$('#discount').val('');
	$('#total_hid').val('');
	$('#tax').val('');
	$('#agency').val('');
	$('#net_amount').val('');
}


function set_category()
{
	var cat = $('#type').val();	
	var category = $('input[name="category"]:checked').val();
	

	if(cat != '0')
	{
		//var cat_set = '<label class="col-lg-12">Category</label><ul class="delrom_cus"><li><input type="radio" value="hotel" onchange="category_set();" name="category" checked/> Hotel</li><li><input type="radio" value="package" onchange="category_set();" name="category" /> Package</li></ul>';
			//$('#off_type').html(cat_set);
			
			$('#hid_discount').val('');
			$('#discount').val('');
			$('#tax').val('');
			$('#net_amount').val('');
		
		$('#offline_discount').css("display", "none");
		$('#agency_voucher').css("display", "block");
		$('#agency_commision').css("display", "block");
		
		if(category == 'package')
		{
			category_set();
			
		}
		else
		{
			offline_room_check();
		}
		
			
	}
	else
	{
		//var cat_set = '<input type="hidden" value="hotel"  name="category" /> ';
		$('#offline_discount').css("display", "block");
		$('#agency_voucher').css("display", "none");
		$('#agency_commision').css("display", "none");
		//$('#off_type').html(cat_set);
		$('#tax').val('');
		$('#package').html('');	
		$('#net_amount').val('');
		
		if(category == 'package')
		{
			category_set();
			
		}
		else
		{
			offline_room_check();
		}
		
	}
}

function onlyNumbers(event) {
        var charCode = (event.which) ? event.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
 
        return true;
    }
    
function category_set()
{
	var check_in = $('#check_in').val();
	var check_out = $('#check_out').val();
	var cat = $('input[name="category"]:checked').val();
	
	//	if(((check_in) && (check_out)) && check_out >= check_in)
	if(((check_in) && (check_out)))
	{
		
	if(cat == 'package')
	{
		$.ajax({
			url: baseurl+'offline/getPackages/'+check_in+'/'+check_out+'/'+cat,
			type:"POST",
			success:function(result){
				//alert(result);
		 $("#package").html(result);
	  	}
	  	});
		
		$('#room_available').html('');
		$('#hid_discount').val('');
		$('#discount').val('');
		$('#total').val('');
		$('#total_hid').val('');
		$('#offline_tax').css("display", "none");
		$("#net_amount").val(''); 
		$("#agency").val(''); 
		
	}
	else 
	{ 
	
	
	$("#package").html(''); 
	$("#agency").val(''); 
	$("#offline_tax").val(''); 
	$('#offline_tax').css("display", "block");
	$("#net_amount").val(''); 
	offline_room_check();
	}
	
	}
}



function package_room_check() {
	var check_in = $('#check_in').val();
	var check_out = $('#check_out').val();
	var pack= $('#pack').val();
	var cat = $('#type').val();	
	
	//if(((check_in) && (check_out)) && check_out >= check_in)
	if(((check_in) && (check_out)))
	{
	  	 $.ajax({
		  url: baseurl + "offline/package_room_available/"+check_in+"/"+check_out+"/"+pack+"/"+cat,
		  type:"POST",
	  	  success:function(result){
	  	  	
	  	  	//alert(result);
		 $("#room_available").html(result);
		 
		 $('#hid_discount').val('');
		$('#discount').val('');
		$('#total').val('');
		$('#total_hid').val('');
		$('#agency').val('');
		$('#net_amount').val('');
		
		if(cat!=0)
			{
				$('#food_paln').css("display", "none");
			}
	
	  	}});
		
	} 
	else { $("#room_available").html(''); }
}




function food_plan()
{
	
	var days = $('#no_of_days').val();	
	var person =$('#no_of_persons').val();	
	var total = $('#total').val();	
	var net_price =$('#net_amount').val();	
	var tax=$('#hotel_tax').val();
	var discount = $('#discount').val();
	 
	var prices,food_amount =0;
	var plans = []; // take an array to store values
	$('input[type="checkbox"][class="food"]:checked').each(function(){
	  plans.push($(this).val());
	});
	
	for(var i=0;i<plans.length;i++)
	{
		prices = plans[i].split(",");
		food_amount+=Number(prices);
		
	}
	
	var total_food_price = days * person * food_amount;
	var total_amount = Number(total)+Number(total_food_price);
	var food_tax =(total_amount*tax)/100;
	var total_tax = Number(total_amount)+Number(food_tax);
	
	
	if(discount!='')
	{
		var total_tax = total_tax - discount;
	}
	
	$('#total_food').val(total_food_price);
	$('#net_amount').val(total_tax);
	$('#tax').val(food_tax);
	
	
}
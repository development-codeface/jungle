var x = 1;
var max_fields_image      = 5;

$(function() {

	$(".package_image_add").click(function(e)
	    {
	    	if(x < max_fields_image){ 
            x++;
	    	var html ='<div class="form-group row"><label class="col-lg-2">Image</label><input class="col-lg-6 form-control " type="file" name="package_image[]"><div class="col-lg-2 text-right"><button type="button" class="btn btn-success room_image_remove" onClick="remove_package_image(this)"  >Remove</button></div></div>';
	        $(".room_image_row").append(html);
	       }
	    });
	
});

 
function remove_package_image(ele)
{
	$(ele).parent().parent().remove();
	x--;
}  




$(function() {

	$(".package_vehicle_add").click(function(e)
	    {
	    	
	    	var html ='<div class="form-group row"><input class="col-lg-3 form-control" type="text" name="vehicle[]"><input class="col-lg-2 form-control " type="text" name="capacity[]" onkeypress="return onlyNumbers(event)"><input class="col-lg-2 form-control " type="text" name="vehicle_charge[]" onkeypress="return onlyNumbersDots(event)"><div class="col-lg-2 text-right"><button type="button" class="btn btn-success room_image_remove" onClick="remove_package_vehicle(this)"  >Remove</button></div></div>';
	        $(".package_vehicles").append(html);
	       
	    });
	
});

function remove_package_vehicle(ele)
{
	$(ele).parent().parent().remove();
	
}  




$(function() {

	$(".package_day_add").click(function(e)
	    {
	    	
	    	
	    	var html ='<div class="form-group row"><input class="col-lg-3 form-control " type="text" name="package_day[]"><input class="col-lg-3 form-control " type="text" name="day_title[]"><textarea  class="col-lg-3 form-control " rows="3" style="height: 35px;" name="day_description[]" id="day_description"></textarea><div class="col-lg-2 text-right"><button type="button" class="btn btn-success room_image_remove" onClick="remove_package_day(this)"  >Remove</button></div></div>';
	        $(".package_days").append(html);
	      
	    });
	
});

function remove_package_day(ele)
{
	$(ele).parent().parent().remove();
	
}  




function onlyNumbers(event) {
        var charCode = (event.which) ? event.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
 
        return true;
    }
    
    
    function onlyNumbersDots(event) {
        var charCode = (event.which) ? event.which : event.keyCode
       if (charCode > 31 && (charCode < 46 || charCode > 57))
            return false;
 
        return true;
    }
    

//date picker 
// var date = new Date();

// $('#sandbox-container input').datepicker({ format: 'yyyy-mm-dd', startDate : date });
// $('#sandbox-container2 input').datepicker({	format: 'yyyy-mm-dd', startDate : date});



var date = new Date();

$('#sandbox-container input').datepicker({ format: 'dd-mm-yyyy', startDate : date, autoclose : true });

date.setDate(date.getDate()+1); 
//$('#valid_to').datepicker({	format: 'dd-mm-yyyy', startDate : date, autoclose : true}).datepicker("setDate",date);


$('#sandbox-container4 input').datepicker({ format: 'dd-mm-yyyy', startDate : date, autoclose : true }).datepicker("setDate",date);


$('#sandbox-container4 input').datepicker({ format: 'dd-mm-yyyy', startDate : date, autoclose : true }).datepicker("setDate","date");


var y = $('#img_count').val();
var max_fields_image_edit      = 5;

$(function() {

	$(".package_image_edit").click(function(e)
	    {
	    	

	    	if(y < max_fields_image_edit){ 
            y++;
	    	var html ='<div class="form-group row"><label class="col-lg-2">Image</label><input class="col-lg-6 form-control " type="file" name="package_image[]"><div class="col-lg-2 text-right"><button type="button" class="btn btn-success room_image_remove" onClick="remove_package_image_edit(this)"  >Remove</button></div></div>';
	        $(".room_image_row").append(html);
	       }
	    });
	
});

 
function remove_package_image_edit(ele)
{
	$(ele).parent().parent().remove();
	y--;
}  




function openfileDialog() {
    $("#fileLoader").click();
}


function package_refine()
{
	var search_text = $('#holiday_search').val();
	var values = [];
	var dest = [];
	
	$("input:checkbox[class=holiday_destination_search]:checked").each(function () {
	dest.push($(this).val());
   });
   
   $("input:checkbox[class=holiday_night_search]:checked").each(function () {
	values.push($(this).val());
   });
   
  
    var values_length=values.length;
	 var c=0;
	var d="";
	
	var dest_length=dest.length;
	 var e=0;
	var f="";
   
   for (c = 0; c < values_length; c++) 
   {
   	   d +="&nights[]="+values[c];
   }
   for (e = 0; e < dest_length; e++) 
   {
   	   f +="&dest[]="+dest[e];
   }
   
   
   $.ajax({
		type: "get",
		url: baseurl+"packages/refine_search/",
		data:{nights : values, search_text: search_text, dest :dest},
		success:function(res)
		{
			$('#search_refine_result').html(res);
		}
	});
	
	ChangeUrl('Page1', baseurl + "holiday/search_list?hidden-search="+search_text+d+f);
	
	//window.location = baseurl + 'holiday/search_list?hidden-search='+search_text+d+f;
	
}

$(document).ready(function(){

$('#holiday_search').on('keypress keyup',function()
{
	$('#holiday_button').prop('disabled',false);
	if($('#holiday_search').val()=='')
	{
			$('#holiday_button').prop('disabled',true);
	}
});



});




function ChangeUrl(title, url) {
	if ( typeof (history.pushState) != "undefined") {
		var obj = {
			Title : title,
			Url : url
		};
		history.pushState(obj, obj.Title, obj.Url);
	} else {
		alert("Browser does not support HTML5.");
	}
}
<html>
<title>New Booking</title>
<head></head>
<body>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="hedb" style="background:#216393;display: inline-block;width: 100%;">
<div class="email_header col-md-4" style="  background:#216393; color: hsl(0, 0%, 100%); margin-bottom: 25px;  display: inline-block; padding: 15px; text-align: center; text-transform: uppercase;margin: 0;">
<img src="http://www.bookingwings.com/bookingengine/images/logo.png">
</div>
<div class="email_header col-md-8 " style="background:#216393;  float: right;color: hsl(0, 0%, 100%); margin-bottom: 25px;  display: inline-block; padding: 15px; text-align: center; text-transform: uppercase;margin: 0;">
<p class="tagline" style=" font-family: helvetica; font-size:17px;  text-align: right; text-transform: capitalize; margin: 5px;">Travel Easy, Fast and Safe!...</a>
</div>
</div>
</div>


<div class="col-md-12 ">


<div class="container  container_cus" style="width:100%;">
<div class="row bluebbcus" style="padding-top: 40px;background-color:#fbfbfb;">
<div class=" col-md-12 pr bluebbe" style=" display:inline-block; width:100%; padding: 0;background-color:#fbfbfb;border-bottom: 1px dotted hsl(0, 0%, 80%);">
<div class=" bluebb ">
 <div class="col-md-4" id="a" style="width: 33.3333%;float:left;text-align:center;position: relative;padding: 10px 20px; font-size: 20px;position: relative;color: #2E8DEF;  background: #fff;">
<!--<img style="width: 238px; height: 52px;"src="<?php// echo base_url();?><?php// print_r($image[0]->thumb); ?>">-->
</div>
 <div class="col-md-8" style="width: 61.667%;float:left;">
  <div class="col-md-8" style="width: 66.6667%;float:left;">
<h2 class="inv2 " style="  font-family: lato; font-size: 20px;text-transform: uppercase;font-weight: bold;">BOOKING ENGINE CONTACT
</h2>
</div>


</div>




</div>
</div>

<div class="col-md-12 ">
<div class="hotel_Ingo" style="  margin-top: 30px;">


<div class="col-md-12 customer_details"  style=" width: 90%; padding: 15px 30px;">

<p>Name : <span class="col-md-6 cus-dt2" style="padding: 7px; font-family: lato;font-weight: bolder;"><?php echo $_GET['name']?> </span></p>

<p>Email : <span class="col-md-6 cus-dt2" style="padding: 7px; font-family: lato;font-weight: bolder;"><?php echo $_GET['mail']?> </span></p>

<p>Phone : <span class="col-md-6 cus-dt2" style="padding: 7px; font-family: lato;font-weight: bolder;"><?php echo $_GET['phone']?> </span></p>

<p>Business Name : <span class="col-md-6 cus-dt2" style="padding: 7px; font-family: lato;font-weight: bolder;"><?php echo $_GET['busi_name']?> </span></p>

 
</div>


</div>
</div>



<div class=" col-md-12  bluebbcus6 pr" style="background: hsl(0, 0%, 97%) none repeat scroll 0 0;border-top: 1px solid hsl(0, 0%, 80%);color: hsl(0, 0%, 0%);font-family: lato;font-size: 12px;padding: 10px 0;text-align: center;">
<p class="ht_ads">
</p>

</div>
</div>

</div>



</div>

 <div class="col-md-12">
<div class="email_f_foot" style=" background: #216393; color: #fff;padding: 10px;">
 <p class="addres_f" style="  font-family: helvetica;font-size: 13px;font-weight: 500;margin-bottom: 0; margin-top: 20px;  text-align: center;">BUILDING NO.6/349 CHEKITTAVILAKOM, PUTHIYATHURA, PULLUVILA P.O, THIRUVANTHAPURAM, KERALA 695526. </p> 
<p class="focf" style="  font-family: helvetica;font-size: 12px;font-weight: 500;line-height: 25px;padding: 1px 80px;text-align: center; ">
*** This message is intended only for the person or entity to which it is addressed and may contain confidential and/or privileged information. If you have received this message in error, please notify the sender immediately and delete this message from your system ***
<br>
<!-- <a style="color:#fff;" href="#">Facebook</a> | <a  style="color:#fff;"  href="#">Twitter</a> -->
</p>
</div>
</div>
</div>
</div>
</body>
</html>
 <!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<meta content="width=device-width, initial-scale=1" name="viewport">
<meta content="One of the best online hotel booking website provides great deals, discounts and offers – book budget hotels, star hotels, resorts and homestay in Kerala." name="description">
<meta content="" name="author">
<title> Booking Wings - Best Online Hotel Booking Website </title>
<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/social_buttons.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap-datepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>css/custom.css">
<link href="<?php echo base_url();?>css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/owl.theme.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url();?>css/plugins/morris.css">
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>font-awesome-4.4.0/css/font-awesome.min.css">
</head>

<body>
<?php $this->load->view('layout/header');?>
		
	
	<?php $this -> load -> view('layout/menu'); ?>



	
	<div id="page-wrapper">
	
	
		
		<div class="container">
			
			<div class=" col-md-12 about_us_block">
						
<h1>
<small>Travel Easy, Fast and Safe</small>
BOOKINGWINGS.COM
</h1>
			<div class="succes_msg">
			<p>Booking success	</p>
			<a href="<?php echo base_url();?>">Back to home</a>
				</div>
				</div>
			
			</div>
	
		
		
		
			
		
		
		
	</div>
	
	
	
	<?php $this -> load -> view('layout/footer'); ?>



	

	
  <script src="<?php echo base_url();?>js/jquery-1.11.3.min.js"></script>
  <script src="<?php echo base_url();?>js/bootstrap.min.js"></script>
	

<script type="text/javascript" src="<?php echo base_url();?>js/jquery.validate.min.js"></script>
      <script src="<?php echo base_url();?>js/validation.js"></script>
        <script src="<?php echo base_url();?>js/login.js"></script>




</body>

</html> 
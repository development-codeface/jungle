<html>
<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="<?php echo config_item('base_url');?>css/error.css">
<link href="<?php echo config_item('base_url');?>css/bootstrap.css" rel="stylesheet">
<title>Page Not Found </title>
</head>
<body>
<div class="warpper">


<!-- <div class="col-md-6">
fgfg

</div> -->
<div class="col-md-12">
<h3 class="er">404</h3>
<p class="sub_t_e"><span>Oops!..</span>This page not found</p>
<p class="sub_t_e_r">The link might be corrupted   <span>or the page have been removed.</span></p>
<p class="er_btn"><a href="<?php echo config_item('base_url');?>">Go Back Home</a></p>
</div>



</div>

</body>

</html>

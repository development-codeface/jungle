	</div>

		    </div>
		    
		    
			<br>
			
		</div>
				


       </div>
       <!-- /#page-wrapper -->



		
	<!-- Footer >> -->
<div id="footer">
	      <div class="container">
	      	
	      	<div class="row">
	      		
	      		<div class="col-sm-12">
	      			<div class="col-sm-12 footer-row1">
	      			
		      			<div class="col-sm-6 col-md-3 footer_column">
		      			
			      			<ul class="footer_list_cus_4">
			      				<label class="footer_label">Company</label>
			      				<li><a href="<?php echo base_url();?>about">About Us</a></li>
			      				<li><a href="<?php echo base_url();?>contact">Contacts Us</a></li>
			      				<li><a href="<?php echo base_url();?>faq">FAQs</a></li>
			      				<li><a href="<?php echo base_url();?>terms-conditions">Terms and Conditions</a></li>
			      				<li><a href="<?php echo base_url();?>privacy-policy">Privacy Policy</a></li>
			      				<!-- <li><a href="#">Advertise with Us</a></li> -->
			      			</ul>
			      			
			      		</div>
	      		
			      		<div class="col-sm-6 col-md-3 footer_column footr_cat">
			      			
			      			<ul class="footer_list_cus_4">
			      				<label class="footer_label">All Categories</label>
			      				<li><a href="<?php echo base_url();?>hotels">Hotels</a></li>
			      				
			      				<li><a href="<?php echo base_url();?>ayurveda">Ayurveda</a></li>
			      				<li><a href="<?php echo base_url();?>hotel-packages">Hotel Packages</a></li>
			      				<li><a href="<?php echo base_url();?>holiday">Holidays</a></li>
			      				<li><a href="<?php echo base_url();?>homestays">Home Stays</a></li>
			      				<li><a href="<?php echo base_url();?>apartments">Apartments</a></li>
			      			</ul>
			      			
			      		</div>
	      		
			      		<div class="col-sm-6 col-md-3 footer_column">
			      			
			      			<ul class="footer_list_cus_4">
			      				<label class="footer_label">PARTNER WITH US</label>
			      				<li><a href="<?php echo base_url();?>register-your-property">Register Your Property</a></li>
			      			</ul>
			      			
			      		</div>
		      		
			      		<div class="col-sm-6 col-md-3 footer_column">
			      			
			      			<ul class="footer_list_cus_4">
			      				<label class="footer_label">More Links</label>
			      				<li><a href="#">About Us</a></li>
			      				<li><a href="#">Contacts Us</a></li>
			      			</ul>
			      			
			      		</div>
			      		
			      	</div>
	      			
	      		</div>
	      		
	      		
	      		
						
	      		<div class="col-sm-12 newsletter_cus">
	      			<div class="col-sm-12 footer-row1">
	      				
	      		    	<form method="post" action="" name="newsletter" id="newsletter">
	      				<div class="col-sm-6 col-md-6 well footer_column">
	      					
	      					<label class="footer_label">Get latest Deals</label>
	      					
		      				<div class="">
		      					<div class="col-md-8 newsletter_cus_2">
								  <div class="form-group">
								   	<input type="text" class="form-control" name="news_email" id="news_email" placeholder="Enter you email Id">
								   	<div class="err" id="news_ltr"></div>
								  </div>
							  	</div>
							  	<div class="col-md-3 newsletter_cus_3">
								  <div class="form-group">
								   	<input type="submit" class="btn btn-primary" value="Subscribe">
								  </div>
							  	</div>
		      				</div>
		      			</div>
		      			</form>
		      			
		      			
		      			
		      			<div class="col-sm-6 col-md-3 footer_column">
		      				
		      				<p>We accept</p>
							<div>
							<img src="<?php echo base_url();?>img/badge.png">
							</div>
		      				
		      			</div>
		      			
		      			<div class="col-sm-6 col-md-3 footer_column">
		      				
		      				<label class="footer_label">Follow Us</label>
		      				
		      				<span class="social">
		      					<a href="#"><i class="fa fa-facebook-square"></i></a>
		      				</span>
		      				<span class="social">
		      					<a href="#"><i class="fa fa-twitter-square"></i></a>
		      				</span>
		      				<span class="social">
		      					<a href="#"><i class="fa fa-google-plus-square"></i></a>
		      				</span>
		      				<span class="social">
		      					<a href="#"><i class="fa fa-youtube-square"></i></a>
		      				</span>
		      				
		      			</div>
		      		
		      		</div>
		      	</div>

		      	
		      	<div class="col-sm-12 footer_column footer_column_cus">
		      		<p>News or others links goes here</p>
		      	</div>
	      		
	      		
	      		
	      	</div>
	      	
	      </div>
	   </div>
	   
	<div id="copyright">
	      <div class="container">
	        <p class="copyright_p ">Hotel booking 2016. Powered by <a href="http://ryanfait.com/sticky-footer/" style="text-transform: capitalize;font-size: 12px;">Crantia Technologies</a>.</p>
	      </div>
	   </div>
<!-- Footer << -->

	
       
        
<script>
		var baseurl = '<?php echo base_url();?>';
	
	</script>

        
        
        
       
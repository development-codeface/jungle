<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ReportModel extends CI_Model {

  
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function sub_category()
	{
		$this->db->select('tbl_sub_category.name,tbl_sub_category.id');
		$this->db->from('tbl_sub_category');
		$this->db->join('tbl_category','tbl_category.id=tbl_sub_category.category_id');
		$this->db->like('tbl_category.name','hotel');
		$this->db->order_by('tbl_sub_category.name','asc');
        $query_res=$this->db->get();
        $result =$query_res->result();
	
        return $result;
	}
	
	function row_count($category,$status)
	{
		$this->db->select('*');
		$this->db->where('sub_category_id',$category);
		$this->db->where('status',$status);
		$query = $this->db->get('tbl_hotel');
        $result =$query->result(); 
        return count($result);
	}	

	function hotel_list($category,$status,$limit,$start)
	{
		$this->db->select('*');
		$this->db->from('tbl_hotel');
		$this->db->where('sub_category_id',$category);
		$this->db->where('status',$status);
		$this->db->limit($limit,$start);
		$query = $this->db->get();
		
		return $query->result();
		
  	 }
	
	// function select_location($location)
	// {
		 // $this->db->select('*');
		 // $this->db->where('location_id',$location);
		 // $query = $this->db->get('location');
		 // $row= $query->row();
		 // return $row->name;
// 		
	// }

	function select_location($location)
	{
		 $this->db->select('*');
		 $this->db->where('id',$location);
		 $query = $this->db->get('tbl_locations');
		 $row= $query->row();
		 return $row;
		
	}
    
	function all_hotels()
	{
		$this->db->select('id,title');
		$query = $this->db->get('tbl_hotel');
		return $query ->result();
	}
	
	function online_report_count($from,$to,$hotel)
	{
		
		return $this -> db
		-> select('b.*')
		-> from('tbl_user a')
		-> join('tbl_booking b', 'b.user_id = a.id')
		-> where('b.agency', 0)
		-> where('b.user_id !=', 0)
		-> where('b.offline_user', 0)
		-> where('b.date >=', $from)
		-> where('b.date <=', $to)
		-> where('b.hotel_id', $hotel)
		-> group_by('b.booking_number')
		-> get()
		-> num_rows();
		
		
	}

	function online_report($from,$to,$hotel,$limit,$start)
	{
		
		return $this -> db
		-> select('b.*')
		-> from('tbl_user a')
		-> join('tbl_booking b', 'b.user_id = a.id')
		-> where('b.agency', 0)
		-> where('b.user_id !=', 0)
		-> where('b.offline_user', 0)
		-> where('b.date >=', $from)
		-> where('b.date <=', $to)
		-> where('b.hotel_id', $hotel)
		-> group_by('b.booking_number')
		-> limit($limit, $start)
		-> get()
		-> result();
	}
	
	
	function online_cancel_count($from,$to,$hotel)
	{
		
		return $this -> db
		-> select('b.*')
		-> from('tbl_user a')
		-> join('tbl_booking b', 'b.user_id = a.id')
		-> where('b.cancel', 1)
		-> where('b.user_id !=', 0)
		-> where('b.offline_user', 0)
		-> where('b.date >=', $from)
		-> where('b.date <=', $to)
		-> where('b.hotel_id', $hotel)
		-> group_by('b.user_id,b.booking_number')
		-> get()
		-> num_rows();
	}
	
	function online_cancel_report($from,$to,$hotel,$limit,$start)
	{
		
		return $this->db
		-> select('*')
		-> from('tbl_booking')
		-> join('tbl_user','tbl_booking.user_id = tbl_user.id')
		-> where('tbl_booking.cancel',1)
		-> where('tbl_booking.offline_user', 0)
		-> where('tbl_booking.date >=', $from)
		-> where('tbl_booking.date <=', $to)
		-> where('tbl_booking.hotel_id', $hotel)
		-> group_by('tbl_booking.booking_number')
		-> limit($limit, $start)
		-> get()
		-> result();
		
	}
	
	function cancel_update($book_no){
		
	$this->db->set('cancel',2);
	$this->db->where('booking_number',$book_no);
	$this->db->update('tbl_booking');
		
	}
	
   
}

?>
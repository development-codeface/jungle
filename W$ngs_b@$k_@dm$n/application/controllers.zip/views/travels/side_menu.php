
<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                   <li >
                        <a class="remove_click_cus" data-target="#demo3"><img src="<?php echo base_url();?>assets/img/tour_packages_imgs_booking.png" > Travels</a>
                        <ul id="demo3" class="collapse">
                          
                         
                               <li>
                                <a href="<?php echo base_url('travels/add');?>"><i class="fa fa-plus"></i>&nbsp;Add New Travels</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('travels/travelslist');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Travels</a>
                            </li>
                           
                        </ul>
                    </li>
                    
                    
              
                    
                </ul>
            </div>

  </nav>
<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                   <li >
                        <a  class="remove_click_cus"  data-target="#demo3"><img src="<?php echo base_url();?>assets/img/h_reports.png" > Hotels Report</a>
                        <ul id="demo3" class="collapse">
                          
                          
                               <li>
                                <a href="<?php echo base_url('report/hotel_log');?>"><i class="fa fa-th-list"></i>&nbsp;Hotel Log</a>
                            </li>
                          
                          
                               <li>
                                <a href="<?php echo base_url('report/hotelreport');?>"><i class="fa fa-th-list"></i>&nbsp;Hotel Report</a>
                            </li>
							
							  <li>
                                <a href="<?php echo base_url('report/bookingreport');?>"><i class="fa fa-th-list"></i>&nbsp;Booking Report</a>
                            </li>
                                 <li>
                                <a href="<?php echo base_url('report/reservation');?>"><i class="fa fa-th-list"></i>&nbsp;Reservation Report</a>
                            </li>
                               	<li>
                                <a href="<?php echo base_url('report/amendreport');?>"><i class="fa fa-th-list"></i>&nbsp;Booking Amend Report</a>
                            </li>
							   <li>
                                <a href="<?php echo base_url('report/cancelreport');?>"><i class="fa fa-th-list"></i>&nbsp;Booking Cancel Report</a>
                            </li>
							
                        </ul>
                    </li>
                    
                    
                    
                </ul>
            </div>

  </nav>

<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                  
                         
                               <li>
                                <a href="<?php echo base_url('user/userlist');?>"><img src="<?php echo base_url();?>assets/img/user_registers.png" > Registered Users</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('contact/contactlist');?>"><img src="<?php echo base_url();?>assets/img/conatct_admin.png" > Contact Users</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('contact/newsletter');?>"><img src="<?php echo base_url();?>assets/img/conatct_admin.png" > News Subscribers</a>
                            </li>
                           
                    
                  
                
                    
                </ul>
            </div>

  </nav>
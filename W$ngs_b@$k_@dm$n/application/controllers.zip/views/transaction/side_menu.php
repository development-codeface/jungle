
<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    
                  <li>
                        <a href="<?php echo base_url('transaction/commision');?>"><img src="<?php echo base_url();?>assets/img/commission_img_menu.png" > Commision</a>
                  </li>
                    <li>
                        <a href="<?php echo base_url('transaction/list_commision');?>"><img src="<?php echo base_url();?>assets/img/commission_img_menu.png" > Manage Commision</a>
                  </li>
                  
                    <li>
                        <a href="<?php echo base_url('transaction/commision_amount');?>"><img src="<?php echo base_url();?>assets/img/commission_img_menu.png" > Commision Amount</a>
                  </li>
                    
                </ul>
            </div>
  </nav>
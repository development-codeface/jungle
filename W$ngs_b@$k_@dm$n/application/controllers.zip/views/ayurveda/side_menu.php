
<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                   <li >
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-fw fa-arrows-v"></i> Yoga<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo3" class="collapse">
                           <li>
                                <a href="<?php echo base_url('ayurveda/list_yoga');?>"><i class="fa fa-fw fa-table"></i> Manage Yoga</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('ayurveda/room_setting/yoga');?>"><i class="fa fa-fw fa-table"></i> Rate & Availability</a>
                            </li>
                        </ul>
                    </li>
                    
                   <li >
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i class="fa fa-fw fa-arrows-v"></i> Ayurveda<i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo4" class="collapse">
                          
                               <li>
                                <a href="<?php echo base_url('ayurveda/list_ayurveda');?>"><i class="fa fa-fw fa-table"></i> Manage Ayurveda</a>
                              </li>
                              <li>
                                <a href="<?php echo base_url('ayurveda/room_setting/ayurveda');?>"><i class="fa fa-fw fa-table"></i> Rate & Availability</a>
                            </li>
                        </ul>
                    </li>
                    
                
                    
                </ul>
            </div>

  </nav>

<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                   <li >
                        <a class="remove_click_cus" data-target="#demo3"><img src="<?php echo base_url();?>assets/img/tour_package_menu.png" >  Tour Packages <!-- <i class="fa fa-fw fa-caret-down"></i> --></a>
                        <ul id="demo3" class="collapse">
                          
                          
                               <li>
                                <a href="<?php echo base_url('packages/add');?>"><i class="fa fa-plus"></i> Add Tour Packages</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('packages/packagelist');?>"><i class="fa fa-fw fa-table"></i> Manage Packages</a>
                            </li>
							      <li>
                                <a href="<?php echo base_url('packages/booking');?>"><i class="fa fa-fw fa-table"></i> Booking</a>
                            </li>
                           
                        </ul>
                    </li>
                    
                
                    
                </ul>
            </div>

  </nav>

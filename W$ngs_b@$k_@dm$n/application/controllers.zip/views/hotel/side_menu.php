

<div class="collapse navbar-collapse navbar-ex1-collapse">

                <ul class="nav navbar-nav side-nav">

               
<!-- 
                   <li>

                        <a href="javascript:;" data-toggle="collapse" data-target="#demo3"><i class="fa fa-fw fa-arrows-v"></i> Hotels <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul id="demo3" class="collapse"> -->
                        
                            

                               <li>

                                <a href="<?php echo base_url('hotel/category/hotels');?>">	<img src="<?php echo base_url();?>assets/img/hoteLmanage_img1.png" > Manage Hotels</a>

                            </li>

                            

                               <!-- <li>

                                <a href="<?php echo base_url('roomtype/category/hotels');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Rooms</a>

                            </li>

                            

                           

                               <li>

                                <a href="<?php echo base_url('roomcomp/category/hotels');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Rate & availability</a>

                            </li>

                            <li>

                                <a href=""><i class="fa fa-fw fa-table"></i>&nbsp;Booking</a>

                            </li>

                             </li>

                              

                           

                        </ul>

                    </li> -->
                    

                     <!-- <li>

                        <a href="javascript:;" data-toggle="collapse" data-target="#demo2"><i class="fa fa-fw fa-arrows-v"></i> Resorts <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul id="demo2" class="collapse"> -->
                            

                               <li>

                                <a href="<?php echo base_url('hotel/category/resorts');?>"><img src="<?php echo base_url();?>assets/img/resort_management.png" > Manage Resorts</a>

                            </li>

                               

                            <!-- 

                               <li>

                                <a href="<?php echo base_url('roomtype/category/resorts');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Rooms</a>

                            </li>

                            

                           

                               <li>

                                <a href="<?php echo base_url('roomcomp/category/resorts');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Rate & availability</a>

                            </li>

                            <li>

                                <a href=""><i class="fa fa-fw fa-table"></i>&nbsp;Booking</a>

                            </li>

                           

                        </ul>

                    </li>

                    

                      <li>

                        <a href="javascript:;" data-toggle="collapse" data-target="#demo1"><i class="fa fa-fw fa-arrows-v"></i> Apartments <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul id="demo1" class="collapse">

                           -->
                           

                               <li>

                                <a href="<?php echo base_url('hotel/category/apartments');?>"><img src="<?php echo base_url();?>assets/img/Apartment-management.png" >  Manage Apartments</a>

                            </li>

                            

                             
<!-- 
                               <li>

                                <a href="<?php echo base_url('roomtype/category/apartments');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Rooms</a>

                            </li>

                            

                        

                               <li>

                                <a href="<?php echo base_url('roomcomp/category/apartments');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Rate & availability</a>

                            </li>

                            <li>

                                <a href=""><i class="fa fa-fw fa-table"></i>&nbsp;Booking</a>

                            </li>

                        </ul>

                    </li>

                    

                    

                    

                            <li>

                        <a href="javascript:;" data-toggle="collapse" data-target="#demo4"><i class="fa fa-fw fa-arrows-v"></i> Home Stay <i class="fa fa-fw fa-caret-down"></i></a>

                        <ul id="demo4" class="collapse"> -->
                           

                               <li>
                               	

                                <a href="<?php echo base_url('hotel/category/home');?>"><img src="<?php echo base_url();?>assets/img/home_stay_management.png" >  Manage Homestay</a>

                            </li>

                            

                              
<!-- 
                               <li>

                                <a href="<?php echo base_url('roomtype/category/home');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Rooms</a>

                            </li>

                            

                           

                               <li>

                                <a href="<?php echo base_url('roomcomp/category/home');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Rate & availability</a>

                            </li>

                            <li>

                                <a href=""><i class="fa fa-fw fa-table"></i>&nbsp;Booking</a>

                            </li>

                        </ul>

                    </li> -->

                    

                    

                    

                

                    

                </ul>

            </div>



  </nav>

<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                 
                    
                  <li >
                        <a  data-target="#demo2"><img src="<?php echo base_url();?>assets/img/user_registers.png" > Site Users</a>
                        <ul id="demo2" class="collapse">
                          
                            <li>
                                <a href="<?php echo base_url('settings/users');?>"><i class="fa fa-plus"></i>&nbsp;Add Site Users </a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('settings/manageusers');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Site Users</a>
                            </li>
                        </ul>
                    </li>
                    
                    
                      <li >
                        <a  data-target="#demo3"><img src="<?php echo base_url();?>assets/img/Settings_img7.png" >  Settings</a>
                        <ul id="demo3" class="collapse">
                          
                          
                               <li>
                                <a href="<?php echo base_url('settings/changepassword');?>"><i class="fa fa-fw fa-edit"></i>&nbsp;Change Password</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('login/logout');?>"><i class="fa fa-fw fa-power-off"></i>&nbsp;Logout</a>
                            </li>
                           
                        </ul>
                    </li>
                    
              
                    
                </ul>
            </div>

  </nav>

<div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
               
                   <li >
                        <a class="remove_click_cus" data-target="#demo3"><img src="<?php echo base_url();?>assets/img/tour_packages_imgs_booking.png" > Groups</a>
                        <ul id="demo3" class="collapse">
                          
                         
                               <li>
                                <a href="<?php echo base_url('group/add');?>"><i class="fa fa-plus"></i>&nbsp;Add New Group</a>
                            </li>
                               <li>
                                <a href="<?php echo base_url('group/list_group');?>"><i class="fa fa-fw fa-table"></i>&nbsp;Manage Groups</a>
                            </li>
                           
                        </ul>
                    </li>
                    
                    
              
                    
                </ul>
            </div>

  </nav>
<html>
<title>Cancel booking</title>
<head>



</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="hedb" style="background:#216393;display: inline-block;width: 100%;">
<div class="email_header col-md-4" style="  background:#216393; color: hsl(0, 0%, 100%); margin-bottom: 25px;  display: inline-block; padding: 15px; text-align: center; text-transform: uppercase;margin: 0;">
<img src="<?php echo base_url();?>../img/logo_mail.png">
</div>
<div class="email_header col-md-8 " style="background:#216393;  float: right;color: hsl(0, 0%, 100%); margin-bottom: 25px;  display: inline-block; padding: 15px; text-align: center; text-transform: uppercase;margin: 0;">
<p class="tagline" style=" font-family: arial; font-size:23px; font-weight: 400; text-align: right; text-transform: capitalize; margin: 5px;">Travel Easy, Fast and Safe!...</a>
</div>
</div>
</div>
<div class="col-md-12 ">
<div class=" mail_bg" style="background: #EBEAE8; padding: 15px;">
<div class=" mail_bg_p" style="background: #fff;padding: 20px;">
<h6 class="email_user_h" style="color: #44494C;font-family: roboto;font-size: 25px;text-align: center;margin:15px 0px;">Cancel Booking Successfully...</h6>

<p class="email_user_n" style="font-family: roboto;font-weight: 500;">Hi,</p>
<p class="email_cntnt" style="font-family: raleway;font-size: 13px;font-weight: 500;line-height: 25px;">Your booking number : <?php print_r($booking_number);?> successfully cancelled.
 </p>


<br>
<br>
<div class="email_f_cnt" style="font-family: roboto;font-weight: 500;">
<p class="fo_c">
<br/><br/>
Thanks,
<br>
Team Bookingwings.com. 

</a>


</div>
</div>

</div>

</div>
 <div class="col-md-12">
<div class="email_f_foot" style=" background: #216393; color: #fff;padding: 10px;">
 <p class="addres_f" style="  font-family: raleway;font-size: 13px;font-weight: 500;margin-bottom: 0; margin-top: 20px;  text-align: center;">BUILDING NO.6/349 CHEKITTAVILAKOM, PUTHIYATHURA, PULLUVILA P.O, THIRUVANTHAPURAM, KERALA 695526. </p> 
<p class="focf" style="  font-family: raleway;font-size: 12px;font-weight: 500;line-height: 25px;padding: 1px 80px;text-align: center; ">
*** This message is intended only for the person or entity to which it is addressed and may contain confidential and/or privileged information. If you have received this message in error, please notify the sender immediately and delete this message from your system ***
<br>
<a style="color:#fff;" href="#">Facebook</a> | <a  style="color:#fff;"  href="#">Twitter</a>

</p>

</div>

</div>


</div>

</div>
</body>


</html>